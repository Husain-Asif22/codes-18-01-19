import java.io.IOException;

import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.conf.Configuration;


import org.apache.hadoop.conf.Configuration;

public class report {
      
   public static void main(String[] args) throws IOException {

      // Instantiating configuration class
      Configuration con = HBaseConfiguration.create();

      // Instantiating HbaseAdmin class
      HBaseAdmin admin = new HBaseAdmin(con);

      // Instantiating table descriptor class
      HTableDescriptor tableDescriptor = new HTableDescriptor(TableName.valueOf("report"));

      // Adding column families to table descriptor
      tableDescriptor.addFamily(new HColumnDescriptor("employee"));
      tableDescriptor.addFamily(new HColumnDescriptor("device"));

      // Execute the table through admin
      admin.createTable(tableDescriptor);
      System.out.println(" Table created ");
	  
      // Instantiating HTable class
      HTable hTable = new HTable(con, "report");

      // Instantiating Put class
      // accepts a row name.
      // assigning a row key
      Put p = new Put(Bytes.toBytes("1")); 

      // adding values using add() method
      // accepts column family name, qualifier/row name ,value
      p.add(Bytes.toBytes("employee"),Bytes.toBytes("id"),Bytes.toBytes("1001"));

      p.add(Bytes.toBytes("employee"),Bytes.toBytes("name"),Bytes.toBytes("husain"));

      p.add(Bytes.toBytes("employee"),Bytes.toBytes("phone"),Bytes.toBytes("7746764834"));

      p.add(Bytes.toBytes("employee"),Bytes.toBytes("device_id"),Bytes.toBytes("x102"));

      p.add(Bytes.toBytes("employee"),Bytes.toBytes("timings"),Bytes.toBytes("2012-08-03 11:00:00"));
      
      p.add(Bytes.toBytes("device"),Bytes.toBytes("country"),Bytes.toBytes("India"));
	  
      p.add(Bytes.toBytes("device"),Bytes.toBytes("city"),Bytes.toBytes("indore"));
	  
      p.add(Bytes.toBytes("device"),Bytes.toBytes("organization"),Bytes.toBytes("XALT"));
	  
      p.add(Bytes.toBytes("device"),Bytes.toBytes("device"),Bytes.toBytes("card"));
	  
      p.add(Bytes.toBytes("device"),Bytes.toBytes("device_id"),Bytes.toBytes("x101"));
 
      p.add(Bytes.toBytes("device"),Bytes.toBytes("status"),Bytes.toBytes("in"));
	  
      // Saving the put Instance to the HTable.
      hTable.put(p);
      System.out.println("data inserted");
      
      // closing HTable
      hTable.close();
   }
}