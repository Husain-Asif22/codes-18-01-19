import socket
import sys

TCP_IP = '192.168.5.94'
TCP_PORT = 8884

s = socket.socket()
s.bind((TCP_IP, TCP_PORT))
s.listen(5) 
c = s.accept()[0]
while True:
  line = open("/home/ubuntu1/husain/nikaza/user_data/us/nikaza_05_07_18-part-00031.csv").read()
  if line:
    c.send(line.encode())
  else:
    break

s.close()

