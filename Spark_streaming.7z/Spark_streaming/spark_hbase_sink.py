#--packages org.apache.spark:spark-sql-kafka-0-10_2.11:2.3.0
#--packages com.hortonworks:shc-core:1.1.1-2.1-s_2.11


from pyspark.sql.functions import split
from pyspark import SparkConf, SparkContext
from pyspark.sql.functions import explode
from pyspark.sql import SparkSession
from pyspark.sql.functions import split
from pyspark.sql import SQLContext
from pyspark.sql.functions import *
from pyspark.sql.types import *
import json
import happybase
from pyspark.sql import Row

df = spark.readStream.format('kafka').option('kafka.bootstrap.servers', '192.168.5.71:9092').option('subscribe','avl').load()
z = df.selectExpr('CAST(key AS STRING)', 'CAST(value AS STRING)', 'offset')
y = z.select('offset', 'value')
split_col = split(y['value'], ',')
y = y.withColumn('app_id', split_col.getItem(0))
y = y.withColumn('user_idfa', split_col.getItem(1))
y = y.withColumn('user_idfa_limited', split_col.getItem(2))
y = y.withColumn('device_os', split_col.getItem(3))
y = y.withColumn('device_location_lat', split_col.getItem(4))
y = y.withColumn('device_location_lng', split_col.getItem(5))
y = y.withColumn('device_location_accuracy', split_col.getItem(6))
y = y.withColumn('event_localtime', split_col.getItem(7))
y = y.withColumn('event_time_utc', split_col.getItem(8))
y = y.withColumn('event_type', split_col.getItem(9))
y = y.withColumn('app_state', split_col.getItem(10))
y = y.withColumn('application_id', split_col.getItem(11))
y = y.withColumn('ip_address', split_col.getItem(12))
y = y.withColumn('device_location_lat', y['device_location_lat'].cast('double'))
y = y.withColumn('device_location_lng', y['device_location_lng'].cast('double'))
y = y.select('offset','app_id' , 'user_idfa' , 'device_os' , 'device_location_lat' , 'device_location_lng' , 'device_location_accuracy' , 'event_time_utc' , 'event_type' , 'ip_address')
y = y.filter(y['app_id'] != 'app_id')

polygon_data_path = '/home/user1/husain/nikaza/polygon_data/geojson_data.json'

jdata = open(polygon_data_path,'r').read()
pp = json.loads(jdata)
feature_collection = pp['features']
polygon_objects = []
for x in range(len(feature_collection)):
	polygon_objects.append(Polygon(feature_collection[x]['geometry']['coordinates'][0]))

def pop(poly,longitude, latitude):
	return(polygon_objects[poly].contains(Point(longitude,latitude)))

point_in_poly = udf(pop)

class SendToHbase_ForeachWriter:
  def open(self, partition_id, epoch_id):
    c = happybase.Connection('192.168.5.73',9090)
    return True

  def process(self, row):
    happybase.Connection('192.168.5.73',9090).table('t1').put(str(row['offset']), {'cf1:app_id': row['app_id'], 'cf1:user_idfa': row['user_idfa'],
                                     'cf1:device_os': row['device_os'],
                                     'cf1:device_location_lat': str(row['device_location_lat']),
                                     'cf1:device_location_lng': str(row['device_location_lng']),
                                     'cf1:device_location_accuracy': row['device_location_accuracy'],
                                     'cf1:event_time_utc': row['event_time_utc'],
                                     'cf1:event_type': row['event_type'],
                                     'cf1:ip_address': row['ip_address'],
									 'cf1:status': row['status'],
									 'cf1:polygon_id': row['polygon_id']})
  def close(self, err):
    if err:
      raise err	  

for i in range(len(polygon_objects)):
	x = y.withColumn('polygon_id', lit(i))
	x = x.withColumn('status', point_in_poly(lit(i),x['device_location_lng'], x['device_location_lat']))
	x = x.filter(x['status'] == 'true')
	x.writeStream.queryName('example'+str(i)).foreach(SendToHbase_ForeachWriter()).outputMode('complete').start()



