#-------------------------------- import all libraries ------------------------------------------------------

from flask import Flask, render_template, request, Response, send_file, url_for, redirect
import io
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.figure import Figure
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, SparkSession
from pyspark.sql.types import Row, DateType
from pyspark.sql.functions import col , column, when, desc, explode
import pyspark.sql.functions as f
import matplotlib.pyplot as plt
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.ml.tuning import TrainValidationSplit, ParamGridBuilder
import pandas
import numpy
import re
import os
import base64
import re

#-------------------------------------- start the flask app -------------------------------------------------

app = Flask(__name__)
app.config["CACHE_TYPE"] = "null"

os.environ["PYSPARK_PYTHON"]="/usr/bin/python3.5"

# prevent cached responses
@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

conf = SparkConf().setMaster('local[3]').setAppName('test app')
sc = SparkContext(conf = conf)

#----------------------------------- Creating the dataset ----------------------------------------------------

input1 = sc.textFile('/home/ubuntu1/husain/ml-1m/users.dat').map(lambda x:x.split('::'))
input2 = sc.textFile('/home/ubuntu1/husain/ml-1m/movies.dat').map(lambda x:x.split('::'))
input3 = sc.textFile('/home/ubuntu1/husain/ml-1m/ratings.dat').map(lambda x:x.split('::'))
spark = SparkSession(sc)
spark.sparkContext.setLogLevel('WARN')
hasattr(input1, "toDF")
hasattr(input2, "toDF")
hasattr(input3, "toDF")
users = input1.toDF(['user_id','gender','age','occupation','zip_code'])
movies = input2.toDF(['movie_id','title','genre'])
ratings = input3.toDF(['user_id','movie_id','rating','timestamp'])
users_ratings = users.join(ratings,['user_id'], "inner")
dataset = users_ratings.join(movies,['movie_id'], "inner")
dataset = dataset.withColumn("age", col("age").cast("integer"))
dataset = dataset.withColumn("user_id", col("user_id").cast("integer"))
dataset = dataset.withColumn("movie_id", col("movie_id").cast("integer"))
dataset = dataset.withColumn("rating", col("rating").cast("integer"))
dataset = dataset.select('*', (f.from_unixtime('timestamp').cast(DateType())).alias('date'))
dataset = dataset.select('*',f.year(dataset.date).alias('year'))
dataset = dataset.withColumn("timestamp", f.from_unixtime("timestamp", "dd/MM/yyyy HH:MM:SS"))
dataset = dataset.withColumn("occupation", when(dataset["occupation"] == 0, "other").otherwise(when(dataset.occupation == 1, "academic/educator").otherwise(when(dataset.occupation == 2, "artist").otherwise(when(dataset.occupation == 3, "clerical/admin").otherwise(when(dataset.occupation == 4, "college/grad student").otherwise(when(dataset.occupation == 5, "customer service").otherwise(when(dataset.occupation == 6, "doctor/health care").otherwise(when(dataset.occupation == 7, "executive/managerial").otherwise(when(dataset.occupation == 8, "farmer").otherwise(when(dataset.occupation == 9, "homemaker").otherwise(when(dataset.occupation == 10, "K-12 student").otherwise(when(dataset.occupation == 11, "lawyer").otherwise(when(dataset.occupation == 12, "programmer").otherwise(when(dataset.occupation == 13, "retired").otherwise(when(dataset.occupation == 14, "sales/marketting").otherwise(when(dataset.occupation == 15, "scientist").otherwise(when(dataset.occupation == 16, "self-employed").otherwise(when(dataset.occupation == 17, "technician/engineer").otherwise(when(dataset.occupation == 18, "tradesman/craftsman").otherwise(when(dataset.occupation == 19, "unemployed").otherwise(when(dataset.occupation == 20, "writer").otherwise(dataset['occupation']))))))))))))))))))))))
dataset = dataset.select('movie_id','user_id','gender','age','zip_code','rating','timestamp','title','genre','date','year', f.regexp_replace(col("occupation"), "/", "|").alias('occupation'))
dataset_pandas = dataset.toPandas()

#------------------------------------------List of users id and movies id ------------------------------------

users_list = dataset.select('user_id').collect()
users_array = [i.user_id for i in users_list]
users_array = set(users_array)
users_array = list(users_array)

movies_list = dataset.select('movie_id').collect()
movies_array = [i.movie_id for i in movies_list]
movies_array = set(movies_array)
movies_array = list(movies_array)

#--------------------------------------------- building the recommender system -------------------------------

df = dataset.select([c for c in dataset.columns if c in ['user_id', 'movie_id', 'rating']])
(training, test) = df.randomSplit([0.8, 0.2])
als = ALS(userCol="user_id", itemCol="movie_id", ratingCol="rating", coldStartStrategy="drop",nonnegative=True)
param_grid = ParamGridBuilder().addGrid(als.rank, [12,13,14]).addGrid(als.maxIter, [18,19,20]).addGrid(als.regParam, [.17,.18,.19]).build()
evaluator = RegressionEvaluator(metricName="rmse", labelCol="rating", predictionCol="prediction")
tvs = TrainValidationSplit(estimator = als, estimatorParamMaps = param_grid, evaluator=evaluator)
model = tvs.fit(training)
best_model = model.bestModel
predictions = best_model.transform(test)
rmse = evaluator.evaluate(predictions)
users_recs = best_model.recommendForAllUsers(10)
movies_recs = best_model.recommendForAllItems(10)

#-------------------------------------------- flask app --------------------------------------------------------

@app.route('/index')
def index():
	return render_template('index2.html', picture = "/home/ubuntu1/husain/flask_movielens/static/welcome.jpg", data = dataset_pandas.head(100).to_html(), users_recs = "")

@app.route('/occupation_genre', methods = ["POST"])
def occupation_genre():
	if request.method == "POST":
		result = request.form
		value = list()
		for k,v in result.items():
			value.append(v)			
		f = dataset_pandas.loc[dataset_pandas['occupation']==value[0]]
		f2 = f['genre'].value_counts().nlargest(20)
		fig = f2.plot('bar')
		fig.set_xlabel('genre', fontsize = 30)
		fig.set_ylabel('count', fontsize = 30)
		img = io.BytesIO()
		plt.savefig(img, format = 'png',bbox_inches = 'tight', dpi = 400)
		plt.clf()
		plt.close()
		img.seek(0)
		data = base64.b64encode(img.getvalue()).decode('ascii')
		img.close()
		picture = data
		return render_template('index2.html', picture = picture, data = f2.to_frame().to_html())


@app.route('/age_genre', methods = ["POST"])
def age_genre():
	if request.method == "POST":
		result = request.form
		value = list()
		for k,v in result.items():
			value.append(int(v))
		f = dataset_pandas.loc[dataset_pandas['age']==value[0]]
		f2 = f['genre'].value_counts().nlargest(20)
		fig = f2.plot('bar')
		fig.set_xlabel('genre', fontsize = 30)
		fig.set_ylabel('count', fontsize = 30)
		img = io.BytesIO()
		plt.savefig(img, format = 'png',bbox_inches = 'tight', dpi = 400)
		plt.clf()
		plt.close()
		img.seek(0)
		data = base64.b64encode(img.getvalue()).decode('ascii')
		img.close()
		picture = data
		return render_template('index2.html', picture = picture, data = f2.to_frame().to_html())

@app.route('/top_users', methods = ["POST"])
def top_users():
	if request.method == "POST":
		f = dataset_pandas['user_id'].value_counts().nlargest(20)
		fig = f.plot('bar')
		fig.set_xlabel('user_id')
		fig.set_ylabel('count')
		img = io.BytesIO()
		plt.savefig(img, format = 'png',bbox_inches = 'tight', dpi = 400)
		plt.clf()
		plt.close()
		img.seek(0)
		data = base64.b64encode(img.getvalue()).decode('ascii')
		img.close()
		picture = data
		return render_template('index2.html', picture = picture, data = f.to_frame().to_html())		

@app.route('/ages_distribution', methods = ["POST"])
def ages_distribution():
	if request.method == "POST":
		fig = dataset_pandas.hist(column = 'age', bins = 20)
		img = io.BytesIO()
		plt.savefig(img, format = 'png',bbox_inches = 'tight', dpi = 400)
		plt.clf()
		plt.close()
		img.seek(0)
		data = base64.b64encode(img.getvalue()).decode('ascii')
		img.close()
		picture = data
		return render_template('index2.html', picture = picture, data = "")		

@app.route('/gender_ratio', methods = ["POST"])
def gender_ratio():
	if request.method == "POST":
		f = dataset_pandas['gender'].value_counts()
		fig = f.plot('bar')
		fig.set_xlabel('gender', fontsize = 30)
		fig.set_ylabel('count', fontsize = 30)
		img = io.BytesIO()
		plt.savefig(img, format = 'png',bbox_inches = 'tight', dpi = 400)
		plt.clf()
		plt.close()
		img.seek(0)
		data = base64.b64encode(img.getvalue()).decode('ascii')
		img.close()
		picture = data
		return render_template('index2.html', picture = picture, data = f.to_frame().to_html())		


@app.route('/occupation_distributions', methods = ["POST"])
def occupation_distributions():
	if request.method == "POST":
		f = dataset_pandas['occupation'].value_counts()
		fig = f.plot('bar')
		fig.set_xlabel('occupations', fontsize = 30)
		fig.set_ylabel('count', fontsize = 30)
		img = io.BytesIO()
		plt.savefig(img, format = 'png',bbox_inches = 'tight', dpi = 400)
		plt.clf()
		plt.close()
		img.seek(0)
		data = base64.b64encode(img.getvalue()).decode('ascii')
		img.close()
		picture = data
		return render_template('index2.html', picture = picture, data = f.to_frame().to_html())

@app.route('/recommend_movies', methods = ["POST"])
def recommend_movies():
	if request.method == "POST":
		result = request.form
		value = list()
		for k,v in result.items():
			value.append(int(v))
		if value[0] in users_array:
			l = users_recs.where(users_recs.user_id == value[0])
			x = l.withColumn("recommendations", explode(l.recommendations))
			y = x.select('user_id', 'recommendations.*')
			final = y.join(movies, ["movie_id"], "inner")
			final = final.toPandas()
			return render_template('index2.html',picture = "", data = final.to_html())		
		else:
			return render_template('index2.html',picture = "", data = "user_id does not exist")		


@app.route('/recommend_users', methods = ["POST"])
def recommend_users():
	if request.method == "POST":
		result = request.form
		value = list()
		for k,v in result.items():
			value.append(int(v))
		if value[0] in movies_array:
			l = movies_recs.where(movies_recs.movie_id == value[0])
			x = l.withColumn("recommendations", explode(l.recommendations))
			y = x.select('movie_id', 'recommendations.*')
			final = y.join(users, ["user_id"], "inner")
			final = final.toPandas()
			return render_template('index2.html',picture = "", data = final.to_html())		
		else:
			return render_template('index2.html',picture = "", data = "movie_id does not exist")	

#----------------------------------------- main function to start the application ---------------------------------

if __name__ == "__main__":
	app.run(host = '0.0.0.0', port=5265, debug = True)
