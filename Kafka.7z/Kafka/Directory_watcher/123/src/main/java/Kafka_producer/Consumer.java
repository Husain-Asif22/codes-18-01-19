package Kafka_producer;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.function.Supplier;
import org.apache.kafka.clients.consumer.*;

public class Consumer {

	public static void main(String[] args) throws IOException {
		String topic = "avl2";
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = new FileInputStream("C:\\\\Users\\\\u21a49\\\\Desktop\\\\kafka_test\\\\123\\\\src\\\\main\\\\java\\\\Kafka_producer\\\\file_consumer.properties");
			prop.load(input);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		KafkaConsumer<String, Supplier> con = new KafkaConsumer(prop);
		con.subscribe(Arrays.asList(topic));
		while(true) {
			ConsumerRecords<String, Supplier> r = con.poll(100);
			for(ConsumerRecord<String, Supplier> record : r) {
				System.out.println(String.valueOf(record.value()));
			}
			
		}
		
	}

}
